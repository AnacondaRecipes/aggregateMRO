.Last.lib <- function (libpath){
  RevoUtils:::unlinkDeleteList()
 }

